<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserPackageController extends Controller
{

	
}
