<?php

namespace App\Http\Controllers\Front\Account;

use App\Event;
use App\Http\Controllers\Controller;
use App\Message;
use Illuminate\Http\Request;
use Morilog\Jalali\CalendarUtils;

class EventController extends Controller
{
	public function index()
	{
		$user   = auth()->user();
		$events = $user->events()->with('person')->get();
		
		return view('auth.account.events.index', [ 'events' => $events ]);
	}
	
	public function create()
	{
		$user   = auth()->user();
		$people = $user->people()->get();
		return view('auth.account.events.create', [ 'people' => $people ]);
	}
	
	public function store(Request $request)
	{
		
		$user      = auth()->user();
		$type      = $request->get('type');
		$person_id = $request->get('person_id');
		$name      = $request->get('name');
		switch ($type) {
			case 'yearly':
				$this->store_yearly_events($request, $user, $type, $person_id, $name);
			break;
			case 'monthly':
				$this->store_monthly_events($request, $user, $type, $person_id, $name);
			break;
			case 'daily':
				$this->store_daily_events($request, $user, $type, $person_id, $name);
			break;
		}
		
		
		dd($request->all());
	}
	
	private function store_yearly_events($request, $user, $type, $person_id, $name)
	{
		
		$date        = CalendarUtils::toGregorian(jdate()->getYear(), $request->get('yearly_month'), $request->get('yearly_day'));
		$date        = date('Y-m-d', strtotime($date[0] . '-' . $date[1] . '-' . $date[2]));
		$remind_at   = date('Y-m-d', strtotime("-" . $request->get('remind_day') . " day", strtotime($date)));
		$remind_time = $request->get('remind_time');
		$extra       = [
			'yearly_period'      => $request->get('yearly_period'),
			'send-sms'           => $request->exists('send-sms'),
			'sms-text'           => $request->get('sms-text'),
			'remind_email'       => $request->exists('remind_email'),
			'remind_sms'         => $request->exists('remind_sms'),
			'remind_description' => $request->get('remind_description'),
		];
		$event       = $user->events()->create([
												   'name'        => $name,
												   'person_id'   => $person_id,
												   'date'        => $date,
												   'remind_at'   => $remind_at,
												   'remind_time' => $remind_time,
												   'type'        => $type,
												   'extra'       => serialize($extra),
											   ]);
	}
	
	private function store_monthly_events($request, $user, $type, $person_id, $name)
	{
		$date        = jdate()->getYear() . '-' . jdate()->getMonth() . '-' . $request->get('monthly_day');
		$remind_at   = date('Y-m-d', strtotime("-" . $request->get('remind_day') . " day", strtotime($date)));
		$remind_time = $request->get('remind_time');
		$extra       = [
			'monthly_period'     => $request->get('monthly_period'),
			'send-sms'           => $request->exists('send-sms'),
			'sms-text'           => $request->get('sms-text'),
			'remind_email'       => $request->exists('remind_email'),
			'remind_sms'         => $request->exists('remind_sms'),
			'remind_description' => $request->get('remind_description'),
		];
		$event       = $user->events()->create([
												   'name'        => $name,
												   'person_id'   => $person_id,
												   'date'        => $date,
												   'remind_at'   => $remind_at,
												   'remind_time' => $remind_time,
												   'type'        => $type,
												   'extra'       => serialize($extra),
											   ]);
	}
	
	private function store_daily_events($request, $user, $type, $person_id, $name)
	{
		$date      = now();
		$remind_at = now();
		$extra     = [
			'daily_period'       => $request->get('daily_period'),
			'daily_hour'         => $request->get('daily_hour'),
			'send-sms'           => $request->exists('send-sms'),
			'sms-text'           => $request->get('sms-text'),
			'remind_email'       => $request->exists('remind_email'),
			'remind_sms'         => $request->exists('remind_sms'),
			'remind_description' => $request->get('remind_description'),
		];
		$event     = $user->events()->create([
												 'name'        => $name,
												 'person_id'   => $person_id,
												 'date'        => $date,
												 'remind_at'   => $remind_at,
												 'remind_time' => 0,
												 'type'        => $type,
												 'extra'       => serialize($extra),
											 ]);
	}
	
	
	
}
