<?php $__env->startSection('content'); ?>
<div class="pages-section">
    <div class="box-title-page bg-silver py-4 mb-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1>ورود/عضویت</h1>
                </div>
            </div>
        </div>
    </div>
    <div class="container">





        <div class="row">
            <div class="col-12 col-md-6">
                <div class="card shadow-sm my-3">
                    <div class="card-body">
                        <h3 class="card-title text-primary">ثبت نام</h3>
                        <form action="">
                            <div class="form-group">
                                <label for="name">نام و نام خانوادگی:</label>
                                <input name="name" id="name" type="text" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="name">ایمیل:</label>
                                <input name="name" id="name" type="email" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="name">شماره تماس:</label>
                                <input name="name" id="name" type="number" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="name">رمز عبور:</label>
                                <input name="name" id="name" type="password" class="form-control">
                            </div>
                            <input type="submit" class="btn btn-gradient" value="عضویت در سایت">
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="card shadow-sm my-3">
                    <div class="card-body">
                        <h3 class="card-title text-primary">ورود به سایت</h3>
                        <form action="">
                            <div class="form-group">
                                <label for="name">شماره موبایل:</label>
                                <input name="name" id="name" type="text" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="name">رمز عبور:</label>
                                <input name="name" id="name" type="password" class="form-control">
                            </div>
                            <input type="submit" class="btn btn-gradient" value="ورود به سایت">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\yadavar\resources\views/orders/auth.blade.php ENDPATH**/ ?>