<?php $__env->startSection('title' , 'رویداد ها'); ?>
<?php $__env->startSection('description' , 'در اینجا می توانید رویداد ها را ببینید'); ?>
<?php $__env->startSection('btn-head'); ?>
    <a class="btn btn-secondary btn-sm" href="<?php echo e(url()->route('event-create')); ?>">افزودن رویداد</a>
    <a class="btn btn-primary btn-sm" href="<?php echo e(url()->route('send-events')); ?>">فعال کن</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>نام مخاطب</th>
            <th>نوع رویداد</th>
            <th>نام رویداد</th>
            <th>تاریخ رویداد</th>
            <th>اکشن</th>
        </tr>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $extra = unserialize($event->extra);
                switch ($event->type) {
                    case 'yearly':
                    $date     = explode('-', $event->date);
                    $now_year = date('Y');
                    if ($date[1] <= date('m')) {
                        $now_year += 1;
                    }
                    $date = "$now_year-$date[1]-$date[2]";
                    break;
                    case 'monthly':
                        $date      = explode('-', $event->date);
                        $now_month = jdate()->getMonth();
                        if ($date[2] <= jdate()->getDay()) {
                            $now_month++;
                        }

                        $date = \Morilog\Jalali\CalendarUtils::toGregorian(jdate()->getYear(), $now_month, $date[2]);
                        $date = $date[0] . '-' . $date[1] . '-' . $date[2];
                    break;
                    case 'daily':
                        $date = date('Y-m-d');
                        $date = daily_next_date($date, $extra['daily_period'], $extra['daily_hour']);

                        $date = $date . ' ' . $extra['daily_hour'] . ':00:00';
                    break;
                }
            ?>
            <tr>
                <td>
                    <?php echo e($event->id); ?>

                </td>

                <td>
                    <?php echo e($event->person->name); ?>

                </td>
                <td><?php echo e($event->type); ?></td>
                <td>
                    <?php echo e($event->name); ?>

                </td>
                <td>
                    <?php echo e(jdate($date)->format('%A, %d %B %y')); ?> (<?php echo e(jdate($date)->ago()); ?> مانده)
                </td>
                <td>
                    <a href="<?php echo e(url()->route('event-edit' , ['id' => $event->id])); ?>" class="btn btn-primary btn-sm">ویرایش</a>
                    <a href="<?php echo e(url()->route('event-destroy' , ['id' => $event->id])); ?>"
                       class="btn btn-danger btn-sm">حذف</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\yadavar\resources\views/auth/account/events/index.blade.php ENDPATH**/ ?>