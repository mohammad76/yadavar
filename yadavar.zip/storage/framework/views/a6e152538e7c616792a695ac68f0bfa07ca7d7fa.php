<?php $__env->startSection('title' , 'مخاطب ها'); ?>
<?php $__env->startSection('description' , 'در اینجا می توانید افراد را ببینید'); ?>
<?php $__env->startSection('btn-head'); ?>
    <a class="btn btn-secondary btn-sm" href="<?php echo e(url()->route('people-create')); ?>">افزودن فرد</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>نام و نام خانوادگی</th>
            <th>موبایل</th>
            <th>اکشن</th>
        </tr>
        <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($person->id); ?>

                </td>
                <td>
                    <?php echo e($person->name); ?>

                </td>
                <td>
                    <?php echo e($person->mobile); ?>

                </td>
                <td>
                    <a href="<?php echo e(url()->route('people-edit' , ['id' => $person->id])); ?>" class="btn btn-primary btn-sm">ویرایش</a>
                    <a href="<?php echo e(url()->route('people-destroy' , ['id' => $person->id])); ?>" class="btn btn-danger btn-sm">حذف</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\yadavar\resources\views/auth/account/people/index.blade.php ENDPATH**/ ?>