<?php $__env->startSection('title' , 'افزودن مخاطب'); ?>
<?php $__env->startSection('description' , 'در اینجا می توانید مخاطب جدید ایجاد کنید'); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" action="<?php echo e(url()->route('people-update' , ['id' => $person->id])); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group col-12 col-md-6">
                <label for="name">نام و نام خانوادگی:</label>
                <input type="text" name="name" value="<?php echo e($person->name); ?>" class="form-control" id="name">
            </div>
            <div class="form-group col-12 col-md-6">
                <label for="mobile">موبایل:</label>
                <input type="number" name="mobile" value="<?php echo e($person->mobile); ?>" class="form-control" id="mobile">
            </div>
            <div class="form-group col-12">
                <input type="submit" class="btn btn-primary" value="ثبت مخاطب">
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\yadavar\resources\views/auth/account/people/edit.blade.php ENDPATH**/ ?>