<?php $__env->startSection('title' , 'پیشخوان'); ?>
<?php $__env->startSection('description' , 'در اینجا می توانید خلاصه ایی از حساب کاربری را ببینید'); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\yadavar\resources\views/auth/account/dashboard.blade.php ENDPATH**/ ?>