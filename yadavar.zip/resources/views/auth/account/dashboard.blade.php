@extends('layouts.master-auth')

@section('title' , 'پیشخوان')
@section('description' , 'در اینجا می توانید خلاصه ایی از حساب کاربری را ببینید')

@section('content')


@endsection